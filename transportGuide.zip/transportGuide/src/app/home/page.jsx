"use client"
import React from 'react'

const page = () => {
    return (
        <div className='text-white text-3xl  h-screen bg-gray-700'>Home page</div>
    )
}

export default page