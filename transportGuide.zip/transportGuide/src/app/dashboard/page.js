import React from 'react'

const dashboard = () => {
  return (
    <div>dashboard</div>
  )
}

export default dashboard